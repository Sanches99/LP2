﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DescontoSalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDesconto_Click(object sender, EventArgs e)
        {
            {
                decimal salarioBruto = 0m;

                if (decimal.TryParse(mskbxSalarioBruto.Text,out salarioBruto))
                {
                    int numeroDeFilhos = 0;

                    if (int.TryParse(mskbxNumeroFilhos.Text ,out numeroDeFilhos))
                    {
                        // Cálculo do INSS
                        decimal descontoINSS = 0m;

                        if (salarioBruto <= 800.47m)
                            descontoINSS = salarioBruto * 0.0765m;
                        else if (salarioBruto <= 1050m)
                            descontoINSS = salarioBruto * 0.0865m;
                        else if (salarioBruto <= 1400.77m)
                            descontoINSS = salarioBruto * 0.09m;
                        else if (salarioBruto <= 2801.56m)
                            descontoINSS = salarioBruto * 0.11m;
                        else
                            descontoINSS = 308.17m;

                        // Cálculo do IRPF
                        decimal descontoIRPF = 0m;

                        if (salarioBruto <= 1257.12m)
                            descontoIRPF = 0m;
                        else if (salarioBruto <= 2512.08m)
                            descontoIRPF = salarioBruto * 0.15m;
                        else
                            descontoIRPF = salarioBruto * 0.275m;

                        // Cálculo do Salário Família (considerando 22.33 por filho)
                        decimal salarioFamilia = numeroDeFilhos * 22.33m;

                        // Cálculo do Salário Líquido
                        decimal salarioLiquido = salarioBruto - descontoINSS - descontoIRPF + salarioFamilia;

                        // Exibir os resultados nas TextBox correspondentes
                        textBoxAliquotaINSS.Text = descontoINSS.ToString("C");
                        textBoxAliquotaIRPF.Text = descontoIRPF.ToString("C");
                        textBoxSalarioFamilia.Text = salarioFamilia.ToString("C");
                        textBoxSalarioLiquido.Text = salarioLiquido.ToString("C");
                     
                    }
                    else
                    {
                        MessageBox.Show("Número de filhos inválido. Insira um valor válido.");
                    }
                }
                else
                {
                    MessageBox.Show("Salário bruto inválido. Insira um valor válido.");
                }
            }
        }
    }

}




