﻿namespace DescontoSalario
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNomeFuncionario = new System.Windows.Forms.Label();
            this.lblSalarioBruto = new System.Windows.Forms.Label();
            this.lblNumeroFilhos = new System.Windows.Forms.Label();
            this.lbllNSS = new System.Windows.Forms.Label();
            this.lblIRPF = new System.Windows.Forms.Label();
            this.lblSalarioFamilia = new System.Windows.Forms.Label();
            this.lblSalarioLiquido = new System.Windows.Forms.Label();
            this.lblDescINSS = new System.Windows.Forms.Label();
            this.lblDescIRPF = new System.Windows.Forms.Label();
            this.mskbxNomeFunc = new System.Windows.Forms.MaskedTextBox();
            this.mskbxSalarioBruto = new System.Windows.Forms.MaskedTextBox();
            this.mskbxNumeroFilhos = new System.Windows.Forms.MaskedTextBox();
            this.textBoxAliquotaINSS = new System.Windows.Forms.TextBox();
            this.textBoxAliquotaIRPF = new System.Windows.Forms.TextBox();
            this.textBoxSalarioFamilia = new System.Windows.Forms.TextBox();
            this.textBoxSalarioLiquido = new System.Windows.Forms.TextBox();
            this.textBoxDescontoINSS = new System.Windows.Forms.TextBox();
            this.textBoxDescontoIRPF = new System.Windows.Forms.TextBox();
            this.btnDesconto = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblNomeFuncionario
            // 
            this.lblNomeFuncionario.AutoSize = true;
            this.lblNomeFuncionario.Location = new System.Drawing.Point(12, 26);
            this.lblNomeFuncionario.Name = "lblNomeFuncionario";
            this.lblNomeFuncionario.Size = new System.Drawing.Size(105, 13);
            this.lblNomeFuncionario.TabIndex = 0;
            this.lblNomeFuncionario.Text = "Nome do funcionário";
            // 
            // lblSalarioBruto
            // 
            this.lblSalarioBruto.AutoSize = true;
            this.lblSalarioBruto.Location = new System.Drawing.Point(49, 59);
            this.lblSalarioBruto.Name = "lblSalarioBruto";
            this.lblSalarioBruto.Size = new System.Drawing.Size(67, 13);
            this.lblSalarioBruto.TabIndex = 1;
            this.lblSalarioBruto.Text = "Salário Bruto";
            // 
            // lblNumeroFilhos
            // 
            this.lblNumeroFilhos.AutoSize = true;
            this.lblNumeroFilhos.Location = new System.Drawing.Point(28, 93);
            this.lblNumeroFilhos.Name = "lblNumeroFilhos";
            this.lblNumeroFilhos.Size = new System.Drawing.Size(89, 13);
            this.lblNumeroFilhos.TabIndex = 2;
            this.lblNumeroFilhos.Text = "Número de Filhos";
            // 
            // lbllNSS
            // 
            this.lbllNSS.AutoSize = true;
            this.lbllNSS.Location = new System.Drawing.Point(28, 210);
            this.lbllNSS.Name = "lbllNSS";
            this.lbllNSS.Size = new System.Drawing.Size(75, 13);
            this.lbllNSS.TabIndex = 3;
            this.lbllNSS.Text = "Alíquota INSS";
            // 
            // lblIRPF
            // 
            this.lblIRPF.AutoSize = true;
            this.lblIRPF.Location = new System.Drawing.Point(28, 247);
            this.lblIRPF.Name = "lblIRPF";
            this.lblIRPF.Size = new System.Drawing.Size(74, 13);
            this.lblIRPF.TabIndex = 4;
            this.lblIRPF.Text = "Alíquota IRPF";
            // 
            // lblSalarioFamilia
            // 
            this.lblSalarioFamilia.AutoSize = true;
            this.lblSalarioFamilia.Location = new System.Drawing.Point(28, 289);
            this.lblSalarioFamilia.Name = "lblSalarioFamilia";
            this.lblSalarioFamilia.Size = new System.Drawing.Size(76, 13);
            this.lblSalarioFamilia.TabIndex = 5;
            this.lblSalarioFamilia.Text = "Salário Família";
            // 
            // lblSalarioLiquido
            // 
            this.lblSalarioLiquido.AutoSize = true;
            this.lblSalarioLiquido.Location = new System.Drawing.Point(28, 326);
            this.lblSalarioLiquido.Name = "lblSalarioLiquido";
            this.lblSalarioLiquido.Size = new System.Drawing.Size(78, 13);
            this.lblSalarioLiquido.TabIndex = 6;
            this.lblSalarioLiquido.Text = "Salário Líquido";
            // 
            // lblDescINSS
            // 
            this.lblDescINSS.AutoSize = true;
            this.lblDescINSS.Location = new System.Drawing.Point(438, 203);
            this.lblDescINSS.Name = "lblDescINSS";
            this.lblDescINSS.Size = new System.Drawing.Size(81, 13);
            this.lblDescINSS.TabIndex = 7;
            this.lblDescINSS.Text = "Desconto INSS";
            // 
            // lblDescIRPF
            // 
            this.lblDescIRPF.AutoSize = true;
            this.lblDescIRPF.Location = new System.Drawing.Point(438, 243);
            this.lblDescIRPF.Name = "lblDescIRPF";
            this.lblDescIRPF.Size = new System.Drawing.Size(80, 13);
            this.lblDescIRPF.TabIndex = 8;
            this.lblDescIRPF.Text = "Desconto IRPF";
            // 
            // mskbxNomeFunc
            // 
            this.mskbxNomeFunc.Location = new System.Drawing.Point(123, 26);
            this.mskbxNomeFunc.Name = "mskbxNomeFunc";
            this.mskbxNomeFunc.Size = new System.Drawing.Size(411, 20);
            this.mskbxNomeFunc.TabIndex = 9;
            // 
            // mskbxSalarioBruto
            // 
            this.mskbxSalarioBruto.Location = new System.Drawing.Point(123, 52);
            this.mskbxSalarioBruto.Mask = "999.999";
            this.mskbxSalarioBruto.Name = "mskbxSalarioBruto";
            this.mskbxSalarioBruto.Size = new System.Drawing.Size(158, 20);
            this.mskbxSalarioBruto.TabIndex = 10;
            // 
            // mskbxNumeroFilhos
            // 
            this.mskbxNumeroFilhos.Location = new System.Drawing.Point(123, 86);
            this.mskbxNumeroFilhos.Name = "mskbxNumeroFilhos";
            this.mskbxNumeroFilhos.Size = new System.Drawing.Size(100, 20);
            this.mskbxNumeroFilhos.TabIndex = 11;
            // 
            // textBoxAliquotaINSS
            // 
            this.textBoxAliquotaINSS.BackColor = System.Drawing.SystemColors.Window;
            this.textBoxAliquotaINSS.Location = new System.Drawing.Point(109, 203);
            this.textBoxAliquotaINSS.Name = "textBoxAliquotaINSS";
            this.textBoxAliquotaINSS.Size = new System.Drawing.Size(100, 20);
            this.textBoxAliquotaINSS.TabIndex = 12;
            // 
            // textBoxAliquotaIRPF
            // 
            this.textBoxAliquotaIRPF.Location = new System.Drawing.Point(109, 244);
            this.textBoxAliquotaIRPF.Name = "textBoxAliquotaIRPF";
            this.textBoxAliquotaIRPF.Size = new System.Drawing.Size(100, 20);
            this.textBoxAliquotaIRPF.TabIndex = 13;
            // 
            // textBoxSalarioFamilia
            // 
            this.textBoxSalarioFamilia.Location = new System.Drawing.Point(110, 282);
            this.textBoxSalarioFamilia.Name = "textBoxSalarioFamilia";
            this.textBoxSalarioFamilia.Size = new System.Drawing.Size(100, 20);
            this.textBoxSalarioFamilia.TabIndex = 14;
            // 
            // textBoxSalarioLiquido
            // 
            this.textBoxSalarioLiquido.Location = new System.Drawing.Point(110, 323);
            this.textBoxSalarioLiquido.Name = "textBoxSalarioLiquido";
            this.textBoxSalarioLiquido.Size = new System.Drawing.Size(100, 20);
            this.textBoxSalarioLiquido.TabIndex = 15;
            // 
            // textBoxDescontoINSS
            // 
            this.textBoxDescontoINSS.Location = new System.Drawing.Point(525, 200);
            this.textBoxDescontoINSS.Name = "textBoxDescontoINSS";
            this.textBoxDescontoINSS.Size = new System.Drawing.Size(100, 20);
            this.textBoxDescontoINSS.TabIndex = 16;
            // 
            // textBoxDescontoIRPF
            // 
            this.textBoxDescontoIRPF.Location = new System.Drawing.Point(525, 236);
            this.textBoxDescontoIRPF.Name = "textBoxDescontoIRPF";
            this.textBoxDescontoIRPF.Size = new System.Drawing.Size(100, 20);
            this.textBoxDescontoIRPF.TabIndex = 17;
            // 
            // btnDesconto
            // 
            this.btnDesconto.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.btnDesconto.Location = new System.Drawing.Point(105, 136);
            this.btnDesconto.Name = "btnDesconto";
            this.btnDesconto.Size = new System.Drawing.Size(122, 38);
            this.btnDesconto.TabIndex = 18;
            this.btnDesconto.Text = "Verifica Desconto";
            this.btnDesconto.UseVisualStyleBackColor = false;
            this.btnDesconto.Click += new System.EventHandler(this.btnDesconto_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnDesconto);
            this.Controls.Add(this.textBoxDescontoIRPF);
            this.Controls.Add(this.textBoxDescontoINSS);
            this.Controls.Add(this.textBoxSalarioLiquido);
            this.Controls.Add(this.textBoxSalarioFamilia);
            this.Controls.Add(this.textBoxAliquotaIRPF);
            this.Controls.Add(this.textBoxAliquotaINSS);
            this.Controls.Add(this.mskbxNumeroFilhos);
            this.Controls.Add(this.mskbxSalarioBruto);
            this.Controls.Add(this.mskbxNomeFunc);
            this.Controls.Add(this.lblDescIRPF);
            this.Controls.Add(this.lblDescINSS);
            this.Controls.Add(this.lblSalarioLiquido);
            this.Controls.Add(this.lblSalarioFamilia);
            this.Controls.Add(this.lblIRPF);
            this.Controls.Add(this.lbllNSS);
            this.Controls.Add(this.lblNumeroFilhos);
            this.Controls.Add(this.lblSalarioBruto);
            this.Controls.Add(this.lblNomeFuncionario);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNomeFuncionario;
        private System.Windows.Forms.Label lblSalarioBruto;
        private System.Windows.Forms.Label lblNumeroFilhos;
        private System.Windows.Forms.Label lbllNSS;
        private System.Windows.Forms.Label lblIRPF;
        private System.Windows.Forms.Label lblSalarioFamilia;
        private System.Windows.Forms.Label lblSalarioLiquido;
        private System.Windows.Forms.Label lblDescINSS;
        private System.Windows.Forms.Label lblDescIRPF;
        private System.Windows.Forms.MaskedTextBox mskbxNomeFunc;
        private System.Windows.Forms.MaskedTextBox mskbxSalarioBruto;
        private System.Windows.Forms.MaskedTextBox mskbxNumeroFilhos;
        private System.Windows.Forms.TextBox textBoxAliquotaINSS;
        private System.Windows.Forms.TextBox textBoxAliquotaIRPF;
        private System.Windows.Forms.TextBox textBoxSalarioFamilia;
        private System.Windows.Forms.TextBox textBoxSalarioLiquido;
        private System.Windows.Forms.TextBox textBoxDescontoINSS;
        private System.Windows.Forms.TextBox textBoxDescontoIRPF;
        private System.Windows.Forms.Button btnDesconto;
    }
}

