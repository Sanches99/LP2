﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_p_15
{
    public partial class Form1 : Form
    {
        Double raio;
        Double altura;
        Double volume;


        public Form1()
        {
            InitializeComponent();
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Label1_Click_1(object sender, EventArgs e)
        {

        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void MaskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void MaskedTextBox2_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void TextBox2_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void Button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void TxtRaio_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtRaio.Text, out raio))
            {
                MessageBox.Show("Raio inválido");
                txtRaio.Focus();
            }
            else
            {
                if (raio <= 0)
                {
                    MessageBox.Show("Raio deve ser maior que zero!");
                    txtRaio.Focus();

                }

            }


        }

        private void TxtAltura_Validating(object sender, CancelEventArgs e)
        {
            if(!double.TryParse(TxtAltura.Text,out altura))
            {
                MessageBox.Show("Altura Inválida");
                e.Cancel = true;

            }
            else
            { 
                if (altura <= 0)
                {
                    MessageBox.Show("Altura deve ser maior que zero!");
                    e.Cancel = true;
                }
            }

        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            TxtAltura.Clear();
            txtRaio.Clear();
            TxtVolume.Clear();


        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            volume = Math.PI * Math.Pow(raio, 2) * altura;

            TxtVolume.Text = volume.ToString("N2");



        }
    }
}
