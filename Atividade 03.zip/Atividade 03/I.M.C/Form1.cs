﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace I.M.C
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCalcular_Click(object sender, EventArgs e)
        {
            // Verificar se os TextBoxes estão vazios
            if (string.IsNullOrWhiteSpace(textBoxPeso.Text) || string.IsNullOrWhiteSpace(textBoxAltura.Text))
            {
                MessageBox.Show("Por favor, preencha os campos de peso e altura.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Converter os valores dos TextBoxes para números
            if (!double.TryParse(textBoxPeso.Text, out double peso) || !double.TryParse(textBoxAltura.Text, out double altura))
            {
                MessageBox.Show("Valores de peso e altura inválidos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Calcular o IMC
            double imc = peso / (altura * altura);

            // Determinar a mensagem com base no IMC
            string mensagem = "";
            if (imc < 18.5)
            {
                mensagem = "Você está abaixo do peso.";
            }
            else if (imc < 24.9)
            {
                mensagem = "Seu peso está normal.";
            }
            else if (imc < 29.9)
            {
                mensagem = "Você está com sobrepeso.";
            }
            else if (imc < 34.9)
            {
                mensagem = "Você está com obesidade grau I.";
            }
            else if (imc < 39.9)
            {
                mensagem = "Você está com obesidade grau II.";
            }
            else
            {
                mensagem = "Você está com obesidade grau III ou mórbida.";
            }

            // Exibir a mensagem em uma MessageBox
            MessageBox.Show($"Seu IMC é: {imc:F2}. {mensagem}", "Resultado do IMC", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}