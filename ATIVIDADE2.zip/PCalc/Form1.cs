﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalc
{
    public partial class Form1 : Form
    {
        double resultado,numero1, numero2;//globais
        public Form1()
        {
            InitializeComponent();
        }


        private void Txt1_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(txt1.Text ,out numero1))
            {
                MessageBox.Show("número 1 inválido!");
                txt1.Focus();
            }
        }

        private void Txt2_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(txt2.Text, out numero2))
            {
                MessageBox.Show("número 2 inválido!");
                txt2.Focus();
            }
        }

        private void Btn3_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero1;
            txt3.Text = resultado.ToString();
        }

        private void Btn4_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
               txt3.Text = resultado.ToString();
        }

        private void Btn5_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txt3.Text = resultado.ToString();
        }

        private void Btn2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo ?",
                    "Saída", MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question) ==
                DialogResult.Yes)
            {
                Close();
            }

        }

        private void Btn1_Click(object sender, EventArgs e)
        {
            txt1.Text = "";
            txt2.Text = "";
            txt3.Text = "";

            // volta para o numero 1 e limpa variáveis
            txt1.Focus();
            resultado = 0;
            numero1 = 0;
            numero2 = 0;
        }

        private void Btn6_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("Não pode dividir por zero!!!", "Erro",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt2.Focus();
            }
            else
            {
                resultado = numero1/ numero2;
                txt3.Text = resultado.ToString();
            }
        }

       


        private void Txt1_TextChanged(object sender, EventArgs e)
        {
            

        }
    }
}
