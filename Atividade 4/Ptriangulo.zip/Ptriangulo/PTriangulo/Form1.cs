﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void TxtladoA_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtladoA, "");
            double ladoA;

            if (!double.TryParse(txtladoA.Text, out ladoA))
            {
                errorProvider1.SetError(txtladoA, "Valor de A inválido");
            }
        }

        private void TxtladoB_Validated(object sender, EventArgs e)
        {
            errorProvider2.SetError(txtladoB, "");
            double ladoB;

            if (!double.TryParse(txtladoB.Text, out ladoB))
            {
                errorProvider2.SetError(txtladoB, "Valor de B inválido");
            }
        }

        private void TxtladoC_Validated(object sender, EventArgs e)
        {
            errorProvider3.SetError(txtladoC, "");
            double ladoC;

            if (!double.TryParse(txtladoC.Text, out ladoC))
            {
                errorProvider3.SetError(txtladoC, "Valor de C inválido");

            }
        }

        private void Btn1_Click(object sender, EventArgs e)
        {
            double ladoA, ladoB, ladoC;

            //testar se os valores são válidos
            if (!double.TryParse(txtladoA.Text, out ladoA) ||
               !double.TryParse(txtladoB.Text, out ladoB) ||
               !double.TryParse(txtladoC.Text, out ladoC))
            {
                MessageBox.Show("Os Valores devem ser numéricos");
            }
            else
            {
                //Condição necessária para ser triângulo
                if (ladoA < (ladoB + ladoC) && ladoA > Math.Abs(ladoB - ladoC) && ladoB < (ladoA + ladoC)
                    && ladoB > Math.Abs(ladoA - ladoC)
                    && ladoC < (ladoA + ladoB) &&
                    ladoC > Math.Abs(ladoA - ladoB))
                {
                    if (ladoA == ladoB && ladoB == ladoC)
                        MessageBox.Show($"os valores {ladoA}, {ladoB}, {ladoC} formam um triãngulo equilátero");
                    else
                    {
                        if (ladoA == ladoB  || ladoA == ladoC || ladoC == ladoB)
                            MessageBox.Show($"os valores {ladoA}, {ladoB} e {ladoC} formam um triângulo isósceles");
                        else
                            MessageBox.Show($"os valores  {ladoA},{ladoB}, {ladoC} formam um triângulo escaleno");
                    }
                }
            }
        }
    }
}

